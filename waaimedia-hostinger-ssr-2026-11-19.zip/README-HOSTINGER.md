# Hostinger SSR deployment

This package must run as a Node.js application. It must **not** be uploaded to
`public_html` as a static website, because each news URL needs the Node server
to generate its article-specific Open Graph image.

1. In hPanel, create a Node.js application using Node.js 22 or later.
2. Upload and extract the deployment ZIP into the application's root directory.
3. From the application's terminal, run `npm ci --omit=dev`.
4. Set the application's start command to `npm start`, then restart it.
   Hostinger supplies the `PORT` environment variable automatically.
5. Point `waaimedia.com` to this Node.js application.

After deployment, open a news URL in a private browser window and view its
page source. It must contain an `og:image` tag whose value is that article's
public `featured_image_url`. Then use Facebook Sharing Debugger's **Scrape
Again** action before testing WhatsApp, which may cache a previous preview.
